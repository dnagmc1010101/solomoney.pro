export enum statusChatEnum {
  default,
  mute,
  ban,
}

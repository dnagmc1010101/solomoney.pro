export enum statusEnum {
  new,
  verified,
  payment,
}

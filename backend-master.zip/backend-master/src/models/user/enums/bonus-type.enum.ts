export enum BonusType {
  QUESTS
}
export class VkUserDto {
  id: number;
  name: string;
  surName: string;
  username: string;
  email: string;
  photo_100: string;
  domain: string;
}

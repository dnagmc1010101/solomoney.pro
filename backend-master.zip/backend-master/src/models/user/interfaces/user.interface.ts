export interface IUser {
  id: string;
  login: string;
  email: string;
  phone: string;
}

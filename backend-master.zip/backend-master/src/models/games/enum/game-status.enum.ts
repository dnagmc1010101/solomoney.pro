export enum GameStatusEnum {
  NEW,
  WIN,
  REJECT
}
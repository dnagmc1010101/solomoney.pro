export interface ICreateSetting {
  key: string;
  value?: string;
  name?: string;
  fid?: string;
}

export interface IReadSetting {
  key: string;
  value?: string;
  fid?: string;
}

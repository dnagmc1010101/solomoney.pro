export interface ITokenPayload {
  id: number;
  status: number;
  role: string;
}

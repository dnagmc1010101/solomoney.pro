export enum TypesEnum {
  FIRST_PAYMENT,
}

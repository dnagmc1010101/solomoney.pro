export enum SocialTypeEnum {
    VK,
    OK,
    FB  
}
export enum GameTypeEnum {
    ROULETTE,
    JACKPOT,
    BATTLE,
    CRASH,
    MINES,  
    DICE,
    HILO
}
<template>
      <Nuxt/>
</template>

<style scoped>
</style>
<script>
  export default {
  }
</script>
